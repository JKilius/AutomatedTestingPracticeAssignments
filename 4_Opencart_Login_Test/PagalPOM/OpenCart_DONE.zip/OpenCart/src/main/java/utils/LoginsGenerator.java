package utils;

public class LoginsGenerator {
}
